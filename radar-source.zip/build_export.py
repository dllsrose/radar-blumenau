from pathlib import Path
import json,zipfile
r=Path(__file__).parent;o=r.parent.parent/'outputs';o.mkdir(exist_ok=True)
h=(r/'dist/index.html').read_text(encoding='utf-8')
for name in ('data.json','audit.json'):
    body=(r/'dist'/name).read_text(encoding='utf-8').replace('<','\\u003c')
    h=h.replace('<script src="app.js"></script>',f'<script id="{name}" type="application/json">{body}</script><script src="app.js"></script>')
h=h.replace('<link rel="stylesheet" href="style.css">','<style>'+(r/'dist/style.css').read_text(encoding='utf-8')+'</style>')
h=h.replace('<script src="app.js"></script>','<script>'+(r/'dist/app.js').read_text(encoding='utf-8')+'</script>')
(o/'Radar-Blumenau.html').write_text(h,encoding='utf-8')
paths=['radar.py','test_radar.py','verify_site.py','requirements.txt','serve.cjs','build_export.py','dist/index.html','dist/style.css','dist/app.js','dist/data.json','dist/audit.json']
with zipfile.ZipFile(r/'radar-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(r/p,p)
    z.write(r/'README-GITHUB.md','README.md')
with zipfile.ZipFile(o/'Radar-Blumenau-fonte.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(r/p,p)
    z.write(r/'README-GITHUB.md','README.md')
    z.write(r/'.github/workflows/radar.yml','.github/workflows/radar.yml')
print('Arquivos exportados; pacote de publicação:',(r/'radar-source.zip').stat().st_size,'bytes')
